function teste() {
    alert("oi mae linda");
}
