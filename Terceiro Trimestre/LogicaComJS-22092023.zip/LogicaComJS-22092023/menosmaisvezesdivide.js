function Parametros(a,b){
    var c = a + b
    var d = a - b
    var e = a*b
    var f = a/b
    return `A soma dos dois numeros é igual a ${c}, a subtração deles é igual a ${d}, a multiplicação ${e}, por fim a divisão é ${f}.`
}
console.log(Parametros(10,2))