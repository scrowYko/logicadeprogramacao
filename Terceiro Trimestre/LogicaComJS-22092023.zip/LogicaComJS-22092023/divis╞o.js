function divide(a,b){
    let resultado = a/b
    let resto = a%b
    return `O resultado da divisão é ${resultado} e o resto desta divisão é ${resto}`
}
console.log(divide(11,5))