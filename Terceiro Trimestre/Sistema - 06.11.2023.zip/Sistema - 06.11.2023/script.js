function abaGasolina() {
  var link = document.getElementById("tema");
  if (link.href.endsWith("style1.css")) {
    link.href = "./styles/style2.css";
  }
}

function abaInicial() {
  var link = document.getElementById("tema");
  if (link.href.endsWith("style2.css")) {
    link.href = "./styles/style1.css";
  }
}

const btn = document.querySelector("#enviar");

btn.addEventListener("click", function (e) {
  e.preventDefault();

  const num = document.querySelector("#litros");
  const teste = document.getElementById("preco") 
  const teste2 = +teste.innerText
  const litros = num.value;
  const resposta = teste2 * litros
  console.log(litros)


  

  console.log(typeof(teste2))

  console.log(resposta)
});
